from pathlib import Path 
import shutil
from ultralytics import YOLO
import cv2

directory_path = Path('../asl_alphabet_train')
target_directory_path = Path('./data')
subfolders = [f for f in directory_path.iterdir() if f.is_dir()]
folders_labels = [f.name for f in directory_path.iterdir() if f.is_dir()]

model = YOLO('./model/yolov8n.pt')

def self_find_coords(path):
    image=cv2.imread(path)
    resized_image = cv2.resize(image, (640,640))
    # cv2.imshow("aaa", resized_image)
    # cv2.waitKey(0)
    # cv2.destroyAllWindows()
    results = model.predict(source=resized_image, conf=0.5)
    for result in results:
        for bbox in result.boxes.data:
            x_min, y_min, x_max, y_max = bbox[0:4]
            class_id = bbox[5]
            print(f"Class ID: {class_id}, BBox: ({x_min}, {y_min}, {x_max}, {y_max})")

file_counter = 1
for folder in subfolders:
    image_files = list(folder.glob('*'))[:10]
    for image_file in image_files:
        img_path=image_file.resolve()
        target_file_path = target_directory_path / f"{file_counter:04d}{image_file.suffix}"
        file_counter+=1
        shutil.copy(image_file, target_file_path)
        self_find_coords(img_path)
        break
    break
        